﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame
{
    class Player
    {
        string myName;
        List<Card> myHand;

        public Player(string name)
        {
            myName = name;
            myHand = new List<Card>();
        }
        public List<Card> theHand
        {
            get
            {
                return myHand;
            }
            set
            {
                myHand = value;
            }
        }

        public string theName
        {
            get
            {
                return myName;
            }
            set
            {
                myName = value;
            }
        }
        public void addCard(Card card)
        {
            myHand.Add(card);
        }
        public string showHand()
        {
            int length = myHand.Count;
            string returnString = "";
            for(int i = 0; i < length; i++)
            {
                returnString = returnString +  myHand[i].ToString() + " \n";
            }
            Console.WriteLine(myHand[0].ToString());
            return returnString;
        }

    }
}
