﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame
{
    public class Card
    {
        const int DEFaULT_VALUE = 1;
        const char DEFAULT_SUIT = 'A';
        int myValue;
        char mySuit;

        public Card()
        {
            mySuit = DEFAULT_SUIT;
            myValue = DEFaULT_VALUE;
        }
        public Card(int aValue, char aSuit)
        {
            mySuit = aSuit;
            myValue = aValue;
        }

        public int Value
        {
            get
            {
                return myValue;
            }
            set
            {
                myValue = value;
            }
        }
        public char Suit
        {
            get
            {
                return mySuit;
            }
            set
            {
                mySuit = value;
            }
        }
        public override string ToString()
        {
            return string.Format("Card Value: {0} Suit: {1}", myValue, mySuit);
        }
    }
}
