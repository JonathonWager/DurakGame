﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Player player1 = new Player("Jon");
            Deck playDeck = new Deck();
            playDeck.shuffleDeck();

            DealCards(6, player1, playDeck);


            Console.WriteLine(player1.showHand());

        }

        public static void DealCards(int cards, Player player, Deck theDeck)
        {
            for(int i = 0; i < cards; i++)
            {
                player.addCard(theDeck.drawCard());
            }
        }
    }
}
